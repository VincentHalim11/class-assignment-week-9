﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace class_asisgnment_week_9
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {
            txt_pass.PasswordChar = '*';
        }

        private void txt_cek_TextChanged(object sender, EventArgs e)
        {
            txt_cek.PasswordChar = '*';
        }
        public void usename (string name)
        {

        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            
        }
    }
}
