﻿namespace class_asisgnment_week_9
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_pass = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_cek = new System.Windows.Forms.TextBox();
            this.lbl_cek = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(274, 444);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(214, 48);
            this.btn_login.TabIndex = 10;
            this.btn_login.Text = "login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // txt_pass
            // 
            this.txt_pass.Location = new System.Drawing.Point(248, 250);
            this.txt_pass.Name = "txt_pass";
            this.txt_pass.Size = new System.Drawing.Size(382, 31);
            this.txt_pass.TabIndex = 9;
            this.txt_pass.TextChanged += new System.EventHandler(this.txt_pass_TextChanged);
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(245, 163);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(382, 31);
            this.txt_name.TabIndex = 8;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(115, 256);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(104, 25);
            this.lbl_password.TabIndex = 7;
            this.lbl_password.Text = "password";
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(115, 163);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(107, 25);
            this.lbl_name.TabIndex = 6;
            this.lbl_name.Text = "username";
            // 
            // txt_cek
            // 
            this.txt_cek.Location = new System.Drawing.Point(248, 343);
            this.txt_cek.Name = "txt_cek";
            this.txt_cek.Size = new System.Drawing.Size(382, 31);
            this.txt_cek.TabIndex = 12;
            this.txt_cek.TextChanged += new System.EventHandler(this.txt_cek_TextChanged);
            // 
            // lbl_cek
            // 
            this.lbl_cek.AutoSize = true;
            this.lbl_cek.Location = new System.Drawing.Point(115, 349);
            this.lbl_cek.Name = "lbl_cek";
            this.lbl_cek.Size = new System.Drawing.Size(98, 25);
            this.lbl_cek.TabIndex = 11;
            this.lbl_cek.Text = "cek pass";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 685);
            this.Controls.Add(this.txt_cek);
            this.Controls.Add(this.lbl_cek);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_pass);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_name);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox txt_pass;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_cek;
        private System.Windows.Forms.Label lbl_cek;
    }
}