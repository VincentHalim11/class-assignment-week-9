﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace class_asisgnment_week_9
{
    public partial class Form1 : Form
    {
        List<string> name = new List<string>();
        List<string> password = new List<string>();
        Form2 form2;
        bool cek;
        public Form1()
        {
            InitializeComponent();
            name.Add("admin");
            password.Add("admin");
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            for(int i = 0;i < name.Count; i++)
            {
                if (name[i] == txt_name.Text && password[i] == txt_pass.Text)
                {
                    this.Hide();
                    form2 = new Form2(this);
                    form2.User(name[i]);
                    form2.ShowDialog();
                    cek = true;
                    
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                MessageBox.Show("password atau username salah");
            }
        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {
            txt_pass.PasswordChar = '*';
        }

        public void kirim (string username, string password)
        {

        }
    }
}
